# to_do_list_authentication
2 module simple authentication swing based simple apllication

//importing sql file

Go to mysql Workbench

import database.sql file 

Click on go to run sql queries

Give url,user and password in the JdbcConnectionInstance class 

Run todolistsampleapp as java application

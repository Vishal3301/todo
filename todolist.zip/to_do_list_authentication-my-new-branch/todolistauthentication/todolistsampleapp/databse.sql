create database todolistdemo;
use todolistdemo;
create table todolistdemo(email varchar(20) primary key, password integer);
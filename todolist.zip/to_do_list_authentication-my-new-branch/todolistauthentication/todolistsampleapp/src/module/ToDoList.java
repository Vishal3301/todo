package module;

import loginpannel.LoginForm;

//main class
public class ToDoList {
	
	public static void main(String[] args) throws Exception{
				
		new LoginForm();
	}

}

package user;

public class UserPasswordContainer {
	
	private String passvalue;

	public String getPassvalue() {
		return passvalue;
	}

	public void setPassvalue(String passvalue) {
		this.passvalue = passvalue;
	}

}

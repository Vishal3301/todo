/**
 * 
 */
/**
 * 
 */
module todolistsampleapp {
	requires java.desktop;
	requires java.sql;
}